import { Component } from '@angular/core';

import tinymce from 'tinymce';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tinymce';
  public editorOptions1!: Object;
  
  ngOnInit()  {
    this.editorOptions1 = {
      height: 450,
      base_url: '/tinymce',
      suffix: '.min',
      selector: 'textarea',
      plugins: [
        'paste importcss searchreplace autolink directionality',
        'visualblocks visualchars image link media table charmap hr nonbreaking anchor',
        'toc  advlist lists wordcount imagetools textpattern noneditable help charmap quickbars emoticons  image code equation-editor latex',
      ],
      toolbar: [
        'undo redo | latex | bold italic underline strikethrough | fontselect fontsizeselect formatselect | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat  | charmap emoticons | fullscreen  preview save print | insertfile image media template link anchor table equation-editor',
      ],
      equation_editor_config: {
        // url: 'http://localhost:4200/assessment/editor',
        url: 'assets/editor/equation_editor.html', // URL of equation editor Page
        origin: document.location.origin,
        title: 'Equation Editor',
        btn_cancel_text: 'Cancel',
        btn_ok_text: 'Insert',
        mathlive_config: {
          smartMode: true,
        },
      },
      quickbars_insert_toolbar: '',
      image_title: true,
      target_list: false,
      paste_data_images: true,
      tinydrive_max_image_dimension: 1024,
      max_image_dimension: 1024,
      content_css: 'https://unpkg.com/mathlive@0.35.0/dist/mathlive.css',
     
    };

  }
}
